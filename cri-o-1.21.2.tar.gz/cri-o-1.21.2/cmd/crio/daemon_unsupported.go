// +build !linux

package main

func notifySystem() {
	// nothin' doin'
}
